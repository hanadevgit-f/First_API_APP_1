package com.vforkorea.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.vforkorea.app.databinding.ItemBillBinding
import com.vforkorea.app.model.Bill

/**
 * RecyclerView adapter for displaying a list of bills. Each item shows the bill title,
 * proposer summary (e.g., "홍길동 외 3명"), and the computed orientation.
 *
 * @param onItemClick Callback invoked when an item is clicked.
 */
class BillAdapter(
    private var items: List<Bill> = emptyList(),
    private val onItemClick: (Bill) -> Unit
) : RecyclerView.Adapter<BillAdapter.BillViewHolder>() {

    class BillViewHolder(private val binding: ItemBillBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Bill, onClick: (Bill) -> Unit) {
            binding.tvBillName.text = item.billName
            binding.tvProposerSummary.text = item.proposerSummary
            binding.tvOrientation.text = item.orientation
            binding.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BillViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemBillBinding.inflate(inflater, parent, false)
        return BillViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BillViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item, onItemClick)
    }

    override fun getItemCount(): Int = items.size

    fun submitList(list: List<Bill>) {
        items = list
        notifyDataSetChanged()
    }
}