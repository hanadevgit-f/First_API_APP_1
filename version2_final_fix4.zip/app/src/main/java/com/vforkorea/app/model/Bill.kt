package com.vforkorea.app.model

/**
 * Data model representing a single bill item fetched from the National Assembly API.
 *
 * @param billName The name/title of the bill.
 * @param proposers A list of proposer names (as returned by the API) after normalization.
 * @param proposerParties Parallel list of proposer parties corresponding to each proposer.
 * @param orientation The computed political orientation (진보, 보수, 중립).
 * @param major Optional field representing the major contents of the bill (placeholder for future API).
 * @param proposeDate The date on which the bill was proposed (ISO format).
 */
data class Bill(
    val billName: String,
    val proposers: List<String>,
    val proposerParties: List<String>,
    val orientation: String,
    val major: String? = null,
    val proposeDate: String? = null
) {
    /**
     * A summary of proposers for display in the list. Shows the first proposer and the number of additional proposers.
     */
    val proposerSummary: String
        get() = if (proposers.isNotEmpty()) {
            if (proposers.size > 1) {
                "${proposers[0]} 외 ${proposers.size - 1}명"
            } else {
                proposers[0]
            }
        } else {
            ""
        }
}