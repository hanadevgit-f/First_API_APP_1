package com.vforkorea.app.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vforkorea.app.data.BillsRepository
import com.vforkorea.app.model.Bill
import kotlinx.coroutines.launch

/**
 * ViewModel to manage the list of bills and expose data to the UI. It encapsulates the
 * repository and provides methods for refreshing data by different time windows and search terms.
 */
class MainViewModel(private val repository: BillsRepository) : ViewModel() {

    private val _bills = MutableLiveData<List<Bill>>(emptyList())
    val bills: LiveData<List<Bill>> = _bills

    // Keep a copy of the raw list to support search filtering
    private var rawBills: List<Bill> = emptyList()

    /**
     * Refreshes the list of bills, optionally filtered by the number of days.
     * @param days Number of days to look back for proposed bills. 0 or negative means no filter.
     */
    fun refresh(days: Int) {
        viewModelScope.launch {
            val list = repository.fetchBills(days)
            rawBills = list
            _bills.postValue(list)
        }
    }

    /**
     * Filters the list of bills by a search query applied to the bill name. If the query is blank,
     * the full list is restored.
     */
    fun filterByQuery(query: String?) {
        val trimmed = query?.trim() ?: ""
        if (trimmed.isEmpty()) {
            _bills.postValue(rawBills)
        } else {
            val filtered = rawBills.filter { it.billName.contains(trimmed, ignoreCase = true) }
            _bills.postValue(filtered)
        }
    }
}