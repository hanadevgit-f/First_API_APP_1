package com.vforkorea.app.data

import android.util.Log
import com.google.gson.JsonParser
import com.vforkorea.app.BuildConfig
import com.vforkorea.app.model.Bill
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Repository responsible for fetching and parsing data from the National Assembly open API.
 *
 * It keeps an in-memory cache of member information (name → party) to avoid repeated
 * network calls. Before bills are fetched, the members API is called to populate the cache.
 */
class BillsRepository {

    private val client = OkHttpClient()

    /** Cache mapping normalized member names to their party names. */
    private val memberCache: MutableMap<String, String> = mutableMapOf()

    /** Flag indicating whether the member cache has been loaded at least once. */
    private var membersLoaded = false

    /**
     * Normalizes a raw name by removing "의원", whitespace, and non-alphabetic/Korean characters.
     */
    private fun normalizeName(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var name = raw
        name = name.replace("의원", "")
        // remove whitespace
        name = name.replace("\\s+".toRegex(), "")
        // remove special characters except Korean and English letters
        name = name.replace("[^가-힣A-Za-z]".toRegex(), "")
        return name.trim()
    }

    /**
     * Loads the entire list of National Assembly members into [memberCache]. This function should be
     * called before fetching bills so that proposers can be mapped to their current party.
     */
    suspend fun loadMembers() {
        if (membersLoaded) return
        withContext(Dispatchers.IO) {
            try {
                // Build the URL using BuildConfig values. pSize is large enough to include all members.
                val url = StringBuilder()
                    .append(BuildConfig.VFOR_BASE_URL)
                    .append(BuildConfig.VFOR_INFO1)
                    .append("?KEY=").append(BuildConfig.VFOR_API_KEY)
                    .append("&Type=json")
                    .append("&pIndex=1")
                    .append("&pSize=").append(BuildConfig.VFOR_PSIZE)
                    .append("&AGE=").append(BuildConfig.VFOR_AGE)
                    .toString()
                Log.d("BillsRepository", "GET $url")
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.w("BillsRepository", "Members API fail -> HTTP ${'$'}{response.code}")
                        return@withContext
                    }
                    val body = response.body?.string() ?: return@withContext
                    try {
                        val json = JsonParser.parseString(body).asJsonObject
                        if (json.has(BuildConfig.VFOR_INFO1)) {
                            val serviceArray = json.getAsJsonArray(BuildConfig.VFOR_INFO1)
                            if (serviceArray.size() > 1) {
                                val dataObj = serviceArray[1].asJsonObject
                                if (dataObj.has("row")) {
                                    val rows = dataObj.getAsJsonArray("row")
                                    for (element in rows) {
                                        val obj = element.asJsonObject
                                        val name = obj.get("HG_NM")?.asString ?: ""
                                        val party = obj.get("POLY_NM")?.asString ?: ""
                                        val normalized = normalizeName(name)
                                        if (normalized.isNotEmpty()) {
                                            val trimmedParty = when {
                                                party.isBlank() || party == "(없음)" -> ""
                                                else -> party.trim()
                                            }
                                            memberCache[normalized] = trimmedParty
                                        }
                                    }
                                }
                            }
                        }
                        membersLoaded = true
                        Log.d("BillsRepository", "Member cache loaded: ${'$'}{memberCache.size} entries")
                    } catch (e: Exception) {
                        Log.w("BillsRepository", "Members API parse error", e)
                    }
                }
            } catch (e: Exception) {
                Log.w("BillsRepository", "Members API error", e)
            }
        }
    }

    /**
     * Fetches the latest bills from the National Assembly API and returns a list of [Bill] objects.
     *
     * @param days The look-back period in days for filtering by proposal date. If 0 or negative,
     *             the filter is not applied.
     */
    suspend fun fetchBills(days: Int): List<Bill> {
        // Ensure member cache is populated
        loadMembers()
        return withContext(Dispatchers.IO) {
            val results = mutableListOf<Bill>()
            try {
                val url = StringBuilder()
                    .append(BuildConfig.VFOR_BASE_URL)
                    .append(BuildConfig.VFOR_INFO2)
                    .append("?KEY=").append(BuildConfig.VFOR_API_KEY)
                    .append("&Type=json")
                    .append("&pIndex=1")
                    .append("&pSize=").append(BuildConfig.VFOR_PSIZE)
                    .append("&AGE=").append(BuildConfig.VFOR_AGE)
                    .toString()
                Log.d("BillsRepository", "GET ${'$'}url")
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.w("BillsRepository", "Bills API fail -> HTTP ${'$'}{response.code}")
                        return@withContext results
                    }
                    val body = response.body?.string() ?: return@withContext results
                    try {
                        val json = JsonParser.parseString(body).asJsonObject
                        if (json.has(BuildConfig.VFOR_INFO2)) {
                            val serviceArray = json.getAsJsonArray(BuildConfig.VFOR_INFO2)
                            if (serviceArray.size() > 1) {
                                val dataObj = serviceArray[1].asJsonObject
                                if (dataObj.has("row")) {
                                    val rows = dataObj.getAsJsonArray("row")
                                    // Optional date filtering: compute threshold date
                                    val today = LocalDate.now()
                                    val thresholdDate: LocalDate? = if (days > 0) today.minusDays(days.toLong()) else null
                                    val dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd", Locale.getDefault())
                                    for (element in rows) {
                                        val row = element.asJsonObject
                                        val billName = row.get("BILL_NAME")?.asString ?: continue
                                        val proposerStr = row.get("RST_PROPOSER")?.asString ?: ""
                                        val proposeDateRaw = row.get("PROPOSE_DT")?.asString ?: ""
                                        // Filter by date if applicable
                                        if (thresholdDate != null && proposeDateRaw.isNotBlank()) {
                                            try {
                                                val proposeDate = LocalDate.parse(proposeDateRaw, dateFormatter)
                                                if (proposeDate.isBefore(thresholdDate)) {
                                                    continue
                                                }
                                            } catch (e: Exception) {
                                                // If parsing fails, ignore date filter for this item
                                            }
                                        }
                                        // Split proposer names by comma, middle dot, and whitespace
                                        val rawProposers = proposerStr
                                            .split("[ ,·ㆍ]".toRegex())
                                            .map { it.trim() }
                                            .filter { it.isNotEmpty() }
                                        val proposers = mutableListOf<String>()
                                        val parties = mutableListOf<String>()
                                        for (p in rawProposers) {
                                            val normalized = normalizeName(p)
                                            proposers.add(normalized)
                                            val party = memberCache[normalized] ?: ""
                                            parties.add(if (party.isNotEmpty()) party else "")
                                        }
                                        val orientation = computeOrientation(parties)
                                        val bill = Bill(
                                            billName = billName,
                                            proposers = proposers,
                                            proposerParties = parties,
                                            orientation = orientation,
                                            major = row.get("SUMMARY")?.asString,
                                            proposeDate = proposeDateRaw
                                        )
                                        results.add(bill)
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("BillsRepository", "Bills API parse error", e)
                    }
                }
            } catch (e: Exception) {
                Log.w("BillsRepository", "Bills API error", e)
            }
            return@withContext results
        }
    }

    /**
     * Determines the orientation (진보, 보수, 중립) based on the list of party names.
     * If at least 75% of proposers share a progressive or conservative party, that orientation is used.
     */
    private fun computeOrientation(parties: List<String>): String {
        if (parties.isEmpty()) return "중립"
        // Define sets of party names considered progressive or conservative
        val progressives = setOf("정의당", "더불어민주당", "조국혁신당")
        val conservatives = setOf("국민의힘", "개혁신당")
        var progressiveCount = 0
        var conservativeCount = 0
        val total = parties.size
        for (party in parties) {
            val trimmed = party.replace(" ", "")
            when {
                progressives.contains(trimmed) -> progressiveCount++
                conservatives.contains(trimmed) -> conservativeCount++
            }
        }
        val progressiveRatio = progressiveCount.toDouble() / total
        val conservativeRatio = conservativeCount.toDouble() / total
        return when {
            progressiveRatio >= 0.75 -> "진보"
            conservativeRatio >= 0.75 -> "보수"
            else -> "중립"
        }
    }
}