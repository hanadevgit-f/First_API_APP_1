package com.vforkorea.app.model

/**
 * Simple model representing a member (lawmaker) and their party.
 */
data class Member(
    val name: String,
    val party: String
)