package com.vforkorea.app.model

/**
 * Data model representing a single bill item fetched from the National Assembly API.
 *
 * @param billName The name/title of the bill.
 * @param proposers A list of proposer names (as returned by the API) after normalization.
 * @param proposerParties Parallel list of proposer parties corresponding to each proposer.
 * @param orientation The computed political orientation (진보, 보수, 중립).
 * @param major Optional field representing the major contents of the bill (placeholder for future API).
 * @param proposeDate The date on which the bill was proposed (ISO format).
 */
data class Bill(
    val billName: String,
    val proposers: List<String>,
    val proposerParties: List<String>,
    val orientation: String,
    val major: String? = null,
    val proposeDate: String? = null
    ,
    /**
     * 고유 의안 ID. 국회의원 발의법률안 API(row.BILL_ID)에서 제공되며, 세부
     * 내용 페이지를 구성하는 데 사용될 수 있다. 선택 사항이다.
     */
    val billId: String? = null,
    /**
     * 상세 페이지 링크. row.DETAIL_LINK를 저장하여 앱 내부 또는 외부
     * 브라우저에서 열 수 있게 한다.  국회의원 발의법률안 API에서 제공되는
     * URL이다.
     */
    val detailLink: String? = null
) {
    /**
     * A summary of proposers for display in the list. Shows the first proposer and the number of additional proposers.
     */
    val proposerSummary: String
        /**
         * Returns a concise summary of proposers for display in lists.
         * If there are multiple proposers it will show the first name followed by
         * the count of remaining proposers using the Korean classifier "인" to
         * satisfy the user's requirement (e.g. "홍길동 외 3인").
         */
        get() = if (proposers.isNotEmpty()) {
            if (proposers.size > 1) {
                "${proposers[0]} 외 ${proposers.size - 1}인"
            } else {
                proposers[0]
            }
        } else {
            ""
        }
}