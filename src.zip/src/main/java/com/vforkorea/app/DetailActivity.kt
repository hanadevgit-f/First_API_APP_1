package com.vforkorea.app

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import android.net.Uri
import android.content.Intent
import com.google.gson.Gson
import com.vforkorea.app.databinding.ActivityDetailBinding
import com.vforkorea.app.model.Bill
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Displays detailed information about a single bill. Users can expand the proposer list to see
 * each proposer with their party, and can navigate back using the toolbar's back arrow.
 */
class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    // Reusable HTTP client for summarization calls
    private val httpClient by lazy { OkHttpClient() }

    // Keep a reference to the bill for callbacks
    private var currentBill: Bill? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up toolbar with back navigation
        setSupportActionBar(binding.detailToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.detailToolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // Retrieve the bill JSON and parse it
        val json = intent.getStringExtra("bill_json")
        val bill = if (json != null) Gson().fromJson(json, Bill::class.java) else null
        if (bill != null) {
            currentBill = bill
            bindBill(bill)
        }
    }

    /**
     * Binds a [Bill] object's fields to the corresponding UI elements.
     */
    private fun bindBill(bill: Bill) {
        binding.tvDetailBillName.text = bill.billName
        binding.tvDetailProposerSummary.text = bill.proposerSummary
        binding.tvDetailOrientation.text = "성향: ${bill.orientation}"
        // Show major content if available; otherwise keep placeholder text (defined in XML)
        bill.major?.let {
            binding.tvDetailMajor.text = it
        }
        // Populate proposer list in the expandable layout
        populateProposers(bill)
        // Toggle behavior
        binding.btnToggleProposers.setOnClickListener {
            toggleProposerList()
        }
        binding.btnCloseProposers.setOnClickListener {
            hideProposerList()
        }

        // Fetch and display a condensed summary when the user taps the summarize button.
        binding.btnSummarize.setOnClickListener {
            onSummarizeClicked()
        }

        // Show or hide the detail link button based on availability
        val link = bill.detailLink
        if (!link.isNullOrBlank()) {
            binding.btnOpenDetail.visibility = View.VISIBLE
            binding.btnOpenDetail.setOnClickListener {
                try {
                    val uri = Uri.parse(link)
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    startActivity(intent)
                } catch (_: Exception) {
                    // ignore invalid URI
                }
            }
        } else {
            binding.btnOpenDetail.visibility = View.GONE
        }
    }

    /**
     * Populates the proposer list layout with each proposer and their party in parentheses.
     */
    private fun populateProposers(bill: Bill) {
        binding.layoutProposers.removeAllViews()
        val inflater = layoutInflater
        for (i in bill.proposers.indices) {
            val name = bill.proposers[i]
            val party = bill.proposerParties.getOrNull(i) ?: ""
            val text = if (party.isNotBlank()) {
                "${name} (${party})"
            } else {
                "${name} (${getString(R.string.unknown_party)})"
            }
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 14f
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 4, 0, 4)
            tv.layoutParams = lp
            binding.layoutProposers.addView(tv)
        }
    }

    /** Shows or hides the proposer list based on its current visibility. */
    private fun toggleProposerList() {
        if (binding.layoutProposers.visibility == View.GONE) {
            showProposerList()
        } else {
            hideProposerList()
        }
    }

    /** Shows the proposer list and associated close button. */
    private fun showProposerList() {
        binding.layoutProposers.visibility = View.VISIBLE
        binding.btnCloseProposers.visibility = View.VISIBLE
        binding.btnToggleProposers.visibility = View.GONE
    }

    /** Hides the proposer list and resets the toggle/close buttons. */
    private fun hideProposerList() {
        binding.layoutProposers.visibility = View.GONE
        binding.btnCloseProposers.visibility = View.GONE
        binding.btnToggleProposers.visibility = View.VISIBLE
    }

    /**
     * Called when the user taps the "요약 보기" button.  This function checks
     * whether the current bill contains a major summary (bill.major).  If it
     * does, and an API key has been provided in local.properties, it will
     * asynchronously call the configured summarization service to condense the
     * text.  Once retrieved, the condensed summary is displayed in the
     * tvDetailMajor TextView.  If no API key is set or the service call fails,
     * the original major text is retained.
     */
    private fun onSummarizeClicked() {
        val bill = currentBill ?: return
        val originalText = bill.major ?: return

        // If there is no API key configured, simply reuse the existing summary.
        if (BuildConfig.MEANINGCLOUD_API_KEY.isBlank()) {
            binding.tvDetailMajor.text = originalText
            return
        }

        // Perform network call on a background thread
        lifecycleScope.launch {
            val condensed = withContext(Dispatchers.IO) {
                fetchCondensedSummary(originalText)
            }
            // Update UI on the main thread
            if (!condensed.isNullOrBlank()) {
                binding.tvDetailMajor.text = condensed
            } else {
                // Fallback to original text if summarization fails
                binding.tvDetailMajor.text = originalText
            }
        }
    }

    /**
     * Sends a POST request to the summarization API configured in
     * BuildConfig.  Expects a JSON response with a "summary" field.  Returns
     * the condensed text or null on failure.
     */
    private fun fetchCondensedSummary(text: String): String? {
        return try {
            val formBody = FormBody.Builder()
                .add("key", BuildConfig.MEANINGCLOUD_API_KEY)
                .add("txt", text)
                .add("lang", BuildConfig.SUMMARIZATION_LANG)
                .add("sentences", BuildConfig.SUMMARIZATION_SENTENCES)
                .build()
            val request = Request.Builder()
                .url(BuildConfig.SUMMARIZATION_BASE_URL)
                .post(formBody)
                .build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val json = JsonParser.parseString(body).asJsonObject
                if (json.has("summary")) {
                    json.get("summary").asString
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }
}