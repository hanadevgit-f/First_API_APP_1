package com.vforkorea.app

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.vforkorea.app.data.BillsRepository
import com.vforkorea.app.databinding.ActivityMainBinding
import com.vforkorea.app.model.Bill
import com.vforkorea.app.ui.BillAdapter
import com.vforkorea.app.ui.MainViewModel
import com.vforkorea.app.ui.MainViewModelFactory

/**
 * Main screen that displays a list of bills. Users can filter by time windows (3/7/30 days) and
 * search within bill titles. Tapping on a list item opens a detail screen.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: BillAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up toolbar
        setSupportActionBar(binding.toolbar)

        // Initialize repository and ViewModel
        val repository = BillsRepository()
        val factory = MainViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        // Set up RecyclerView
        adapter = BillAdapter { bill -> onBillClicked(bill) }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        // Observe data
        viewModel.bills.observe(this) { list ->
            adapter.submitList(list)
        }

        // Initial load: default to 7 days
        viewModel.refresh(7)

        // Set up filter buttons
        binding.btn3days.setOnClickListener { viewModel.refresh(3) }
        binding.btn7days.setOnClickListener { viewModel.refresh(7) }
        binding.btn30days.setOnClickListener { viewModel.refresh(30) }

        // Search listener
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.filterByQuery(s?.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun onBillClicked(bill: Bill) {
        val intent = Intent(this, DetailActivity::class.java)
        // Pass the bill details as JSON to the detail screen
        intent.putExtra("bill_json", com.google.gson.Gson().toJson(bill))
        startActivity(intent)
    }
}