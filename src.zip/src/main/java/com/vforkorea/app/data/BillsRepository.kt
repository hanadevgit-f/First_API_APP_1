package com.vforkorea.app.data

import android.util.Log
import com.google.gson.JsonParser
import com.vforkorea.app.BuildConfig
import com.vforkorea.app.model.Bill
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Repository for National Assembly Open API:
 * - info1 (members) name → party cache
 * - info2 (bills)   proposer → party mapping
 */
class BillsRepository {

    private val client = OkHttpClient()

    /** normalized member name → party */
    private val memberCache: MutableMap<String, String> = mutableMapOf()

    private var membersLoaded = false

    private fun normalizeName(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var name = raw
        name = name.replace("의원", "")
        name = name.replace("\\s+".toRegex(), "")
        name = name.replace("[^가-힣A-Za-z]".toRegex(), "")
        return name.trim()
    }

    /** Load member cache once */
    suspend fun loadMembers() {
        if (membersLoaded) return
        withContext(Dispatchers.IO) {
            try {
                // Load all pages of member information.  Each page can include up
                // to VFOR_PSIZE entries.  The API returns fewer records on the
                // last page; continue fetching pages until less than pageSize
                // results are returned or a reasonable limit is reached.
                val pageSize = BuildConfig.VFOR_PSIZE.toIntOrNull() ?: 100
                var pageIndex = 1
                var morePages = true
                var totalCount = 0
                while (morePages && pageIndex <= 10) {
                    val url = StringBuilder()
                        .append(BuildConfig.VFOR_BASE_URL)
                        .append(BuildConfig.VFOR_INFO1)
                        .append("?KEY=").append(BuildConfig.VFOR_API_KEY)
                        .append("&Type=json")
                        .append("&pIndex=").append(pageIndex)
                        .append("&pSize=").append(BuildConfig.VFOR_PSIZE)
                        .append("&AGE=").append(BuildConfig.VFOR_AGE)
                        .toString()
                    Log.d("BillsRepository", "GET $url")
                    val request = Request.Builder().url(url).build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) {
                            Log.w("BillsRepository", "Members API fail -> HTTP ${response.code}")
                            return@use
                        }
                        val body = response.body?.string()
                        if (body.isNullOrEmpty()) {
                            Log.w("BillsRepository", "Members API empty body")
                            return@use
                        }
                        try {
                            val json = JsonParser.parseString(body).asJsonObject
                            if (json.has(BuildConfig.VFOR_INFO1)) {
                                val serviceArray = json.getAsJsonArray(BuildConfig.VFOR_INFO1)
                                if (serviceArray.size() > 1) {
                                    val dataObj = serviceArray[1].asJsonObject
                                    if (dataObj.has("row")) {
                                        val rows = dataObj.getAsJsonArray("row")
                                        // If this page returns fewer than the requested size, stop
                                        if (rows.size() < pageSize) {
                                            morePages = false
                                        }
                                        for (element in rows) {
                                            val obj = element.asJsonObject
                                            val name = obj.get("HG_NM")?.asString ?: ""
                                            val partyRaw = obj.get("POLY_NM")?.asString ?: ""
                                            val normalized = normalizeName(name)
                                            if (normalized.isNotEmpty()) {
                                                val party = if (partyRaw.isBlank() || partyRaw == "(없음)") {
                                                    ""
                                                } else {
                                                    partyRaw.trim()
                                                }
                                                memberCache[normalized] = party
                                                totalCount++
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.w("BillsRepository", "Members API parse error", e)
                        }
                    }
                    pageIndex++
                }
                Log.d("BillsRepository", "Member cache loaded: $totalCount entries")
                membersLoaded = true
            } catch (e: Exception) {
                Log.w("BillsRepository", "Members API error", e)
            }
        }
    }

    /** Fetch bills, map proposers to parties, compute orientation */
    suspend fun fetchBills(days: Int): List<Bill> {
        loadMembers()

        return withContext(Dispatchers.IO) {
            val results = mutableListOf<Bill>()
            try {
                val url = StringBuilder()
                    .append(BuildConfig.VFOR_BASE_URL)
                    .append(BuildConfig.VFOR_INFO2)
                    .append("?KEY=").append(BuildConfig.VFOR_API_KEY)
                    .append("&Type=json")
                    .append("&pIndex=1")
                    .append("&pSize=").append(BuildConfig.VFOR_PSIZE)
                    .append("&AGE=").append(BuildConfig.VFOR_AGE)
                    .toString()

                Log.d("BillsRepository", "GET $url")

                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.w("BillsRepository", "Bills API fail -> HTTP ${response.code}")
                        return@use
                    }

                    val body = response.body?.string()
                    if (body.isNullOrEmpty()) {
                        Log.w("BillsRepository", "Bills API empty body")
                        return@use
                    }

                    try {
                        val json = JsonParser.parseString(body).asJsonObject
                        if (json.has(BuildConfig.VFOR_INFO2)) {
                            val serviceArray = json.getAsJsonArray(BuildConfig.VFOR_INFO2)
                            if (serviceArray.size() > 1) {
                                val dataObj = serviceArray[1].asJsonObject
                                if (dataObj.has("row")) {
                                    val rows = dataObj.getAsJsonArray("row")

                                    // ----- 모호성 없는 날짜 필터 작성 -----
                                    val today = LocalDate.now()
                                    var thresholdDate: LocalDate? = null
                                    if (days > 0) {
                                        thresholdDate = today.minusDays(days.toLong())
                                    }
                                    val dateFormatter =
                                        DateTimeFormatter.ofPattern("yyyyMMdd", Locale.getDefault())

                                    for (element in rows) {
                                        val row = element.asJsonObject

                                        val billNameField = row.get("BILL_NAME")
                                        val billName = if (billNameField != null && !billNameField.isJsonNull) {
                                            billNameField.asString
                                        } else {
                                            null
                                        }
                                        if (billName.isNullOrBlank()) {
                                            continue
                                        }

                                        // Combine representative proposer and co‑proposers into a single string.
                                        val repField = row.get("RST_PROPOSER") ?: row.get("PROPOSER")
                                        val repStr = if (repField != null && !repField.isJsonNull) {
                                            repField.asString
                                        } else {
                                            ""
                                        }
                                        val coField = row.get("PUBL_PROPOSER")
                                        val coStr = if (coField != null && !coField.isJsonNull) {
                                            coField.asString
                                        } else {
                                            ""
                                        }
                                        // If both fields are present, separate them with a space to aid splitting.
                                        val proposerStr = if (repStr.isNotBlank() && coStr.isNotBlank()) {
                                            repStr + " " + coStr
                                        } else if (repStr.isNotBlank()) {
                                            repStr
                                        } else {
                                            coStr
                                        }

                                        val proposeDateField = row.get("PROPOSE_DT")
                                        val proposeDateRaw = if (proposeDateField != null && !proposeDateField.isJsonNull) {
                                            proposeDateField.asString
                                        } else {
                                            ""
                                        }

                                        // 날짜 필터: if 문장으로만 처리 (표현식 X)
                                        var passDateFilter = true
                                        if (thresholdDate != null && proposeDateRaw.isNotBlank()) {
                                            try {
                                                val proposeDate = LocalDate.parse(proposeDateRaw, dateFormatter)
                                                if (proposeDate.isBefore(thresholdDate)) {
                                                    passDateFilter = false
                                                }
                                            } catch (_: Exception) {
                                                // 파싱 실패 시 필터를 통과시킴
                                                passDateFilter = true
                                            }
                                        }
                                        if (!passDateFilter) {
                                            continue
                                        }

                                        // 발의자 파싱
                                        val rawProposers = proposerStr
                                            .split("[ ,·ㆍ]".toRegex())
                                            .map { it.trim() }
                                            .filter { it.isNotEmpty() }

                                        val proposers = mutableListOf<String>()
                                        val parties = mutableListOf<String>()
                                        for (p in rawProposers) {
                                            val normalized = normalizeName(p)
                                            proposers.add(normalized)

                                            val partyFromCache = memberCache[normalized]
                                            val party: String
                                            if (!partyFromCache.isNullOrBlank()) {
                                                party = partyFromCache
                                            } else {
                                                party = ""
                                            }
                                            parties.add(party)
                                        }

                                        val orientation = computeOrientation(parties)

                                        val summaryField = row.get("SUMMARY")
                                        val summary = if (summaryField != null && !summaryField.isJsonNull) {
                                            summaryField.asString
                                        } else {
                                            null
                                        }

                                        // Extract optional identifiers for future detailed lookups
                                        val billIdField = row.get("BILL_ID")
                                        val billId = if (billIdField != null && !billIdField.isJsonNull) {
                                            billIdField.asString
                                        } else {
                                            null
                                        }
                                        val detailLinkField = row.get("DETAIL_LINK")
                                        val detailLink = if (detailLinkField != null && !detailLinkField.isJsonNull) {
                                            detailLinkField.asString
                                        } else {
                                            null
                                        }

                                        val bill = Bill(
                                            billName = billName,
                                            proposers = proposers,
                                            proposerParties = parties,
                                            orientation = orientation,
                                            major = summary,
                                            proposeDate = proposeDateRaw,
                                            billId = billId,
                                            detailLink = detailLink
                                        )
                                        results.add(bill)
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("BillsRepository", "Bills API parse error", e)
                    }
                }
            } catch (e: Exception) {
                Log.w("BillsRepository", "Bills API error", e)
            }

            results
        }
    }

    /** Orientation: 75% rule */
    private fun computeOrientation(parties: List<String>): String {
        if (parties.isEmpty()) return "중립"

        val progressives = setOf("정의당", "더불어민주당", "조국혁신당")
        val conservatives = setOf("국민의힘", "개혁신당")

        var progressiveCount = 0
        var conservativeCount = 0
        val total = parties.size

        for (party in parties) {
            val trimmed = party.replace(" ", "")
            if (progressives.contains(trimmed)) {
                progressiveCount++
            } else if (conservatives.contains(trimmed)) {
                conservativeCount++
            }
        }

        val progressiveRatio = progressiveCount.toDouble() / total
        val conservativeRatio = conservativeCount.toDouble() / total

        return if (progressiveRatio >= 0.75) {
            "진보"
        } else if (conservativeRatio >= 0.75) {
            "보수"
        } else {
            "중립"
        }
    }

    /**
     * Fetches detailed bill information using a separate service code (info3).  The
     * open assembly API exposes multiple datasets; info3 can be configured in
     * local.properties to point at a dataset that returns a bill's full text or
     * metadata.  The exact API contract may differ; this method serves as a
     * placeholder illustrating how to call another endpoint with BILL_ID as a
     * parameter.  If VFOR_INFO3 is blank or the call fails, null is returned.
     *
     * @param billId The unique bill ID from the list API (BILL_ID).
     * @return The detailed content as a string, or null if unavailable.
     */
    suspend fun fetchBillDetail(billId: String): String? {
        val info3 = BuildConfig.VFOR_INFO3
        if (info3.isBlank()) return null
        return withContext(Dispatchers.IO) {
            try {
                val url = StringBuilder()
                    .append(BuildConfig.VFOR_BASE_URL)
                    .append(info3)
                    .append("?KEY=").append(BuildConfig.VFOR_API_KEY)
                    .append("&Type=json")
                    .append("&BILL_ID=").append(billId)
                    .toString()
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext null
                    val body = response.body?.string() ?: return@withContext null
                    try {
                        val json = JsonParser.parseString(body).asJsonObject
                        // The structure of the response is dataset‑dependent.  Here we
                        // attempt to extract a field named "CONTENTS" or "BODY" as a
                        // placeholder for the bill's full text.  Adjust these keys to
                        // match the actual API definition.
                        if (json.has(info3)) {
                            val serviceArray = json.getAsJsonArray(info3)
                            if (serviceArray.size() > 1) {
                                val dataObj = serviceArray[1].asJsonObject
                                if (dataObj.has("row")) {
                                    val rows = dataObj.getAsJsonArray("row")
                                    if (rows.size() > 0) {
                                        val rowObj = rows[0].asJsonObject
                                        // Try multiple possible keys for the bill text
                                        val contentKeys = listOf("CONTENTS", "CONTENT", "BODY", "FULL_TEXT")
                                        for (key in contentKeys) {
                                            if (rowObj.has(key)) {
                                                val text = rowObj.get(key).asString
                                                if (text.isNotBlank()) {
                                                    return@withContext text
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {
                        return@withContext null
                    }
                    return@withContext null
                }
            } catch (_: Exception) {
                return@withContext null
            }
        }
    }
}
