/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.vforkorea.app;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String APPLICATION_ID = "com.vforkorea.app";
  public static final String BUILD_TYPE = "debug";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.0";
  // Field from default config.
  public static final String MEANINGCLOUD_API_KEY = "";
  // Field from default config.
  public static final String SUMMARIZATION_BASE_URL = "https://api.meaningcloud.com/summarization-1.0";
  // Field from default config.
  public static final String SUMMARIZATION_LANG = "ko";
  // Field from default config.
  public static final String SUMMARIZATION_SENTENCES = "3";
  // Field from default config.
  public static final String VFOR_AGE = "22";
  // Field from default config.
  public static final String VFOR_API_KEY = "a69834e736984185a5b063b8c941e5e5";
  // Field from default config.
  public static final String VFOR_BASE_URL = "https://open.assembly.go.kr/portal/openapi/";
  // Field from default config.
  public static final String VFOR_INFO1 = "nwvrqwxyaytdsfvhu";
  // Field from default config.
  public static final String VFOR_INFO2 = "nzmimeepazxkubdpn";
  // Field from default config.
  public static final String VFOR_INFO3 = "";
  // Field from default config.
  public static final String VFOR_PSIZE = "100";
}
